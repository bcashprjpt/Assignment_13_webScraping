import datetime

import requests
from bs4 import BeautifulSoup
import os
import time


search_img = input("enter a text to search images : ")

user_agent ={
    "User_Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36"
}
# This url is used to link the google image for downloading purpose
url = f"https://www.google.com/search?q={search_img}&sca_esv=376a3409f9ec4160&hl=en-GB&sxsrf=AHTn8zoSjbQdWfm_BB-8QtqL2Ze3yfBYXQ:1747485689967&source=hp&biw=1536&bih=730&ei=-YMoaKXOOLHh2roPtrq7sQw&iflsig=ACkRmUkAAAAAaCiSCeuLBDl9WjuU9z6_yCdkXMzRcbO5&ved=0ahUKEwjlrrG-w6qNAxWxsFYBHTbdLsYQ4dUDCBc&uact=5&oq=moon&gs_lp=EgNpbWciBG1vb24yBxAjGCcYyQIyCxAAGIAEGLEDGIMBMggQABiABBixAzIIEAAYgAQYsQMyCBAAGIAEGLEDMgUQABiABDIIEAAYgAQYsQMyBRAAGIAEMgUQABiABDIIEAAYgAQYsQNIpQ5QAFiJCXAAeACQAQCYAZQBoAH_A6oBAzAuNLgBA8gBAPgBAYoCC2d3cy13aXotaW1nmAIEoAKuBMICDhAAGIAEGLEDGIMBGIoFmAMAkgcDMC40oAebF7IHAzAuNLgHrgQ&sclient=img&udm=2"

response = requests.get(url = url, headers=user_agent).text
print(response)

soup = BeautifulSoup(response, 'lxml')
img_tag = soup.find_all('img')
print("print all the tag under this tag: ",img_tag)
print(f"total length: {len(img_tag)}")

no_of_img = int(input("Enter no of images u want to enter : "))

if img_tag:
    if not os.path.exists(search_img):
        os.mkdir(search_img)
        os.chdir(search_img)
    else:
        os.chdir(search_img)

    index = 0
    for tags in img_tag[1:(no_of_img+1)]:
        img_url = tags.get('src')
        response = requests.get(url=img_url).content
        #response= requests.get( url = img_src).text
        #print(img_url)
        #print(response)
        index += 1
        image_name = f"{search_img}_image_{index}.jpg"

        with open(image_name, 'wb') as file:
            file.write(response)

        print(f"Downloaded: {image_name}")

