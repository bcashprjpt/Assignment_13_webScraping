from bs4 import BeautifulSoup
import requests

class PriceTracker:

    def __init__(self,url):
        self.url = url
        self.user_agent = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36"
        }
        self.response = requests.get(url = self.url, headers=self.user_agent).content
        self.soup = BeautifulSoup(self.response, 'lxml')
        self.a_tags =  self.soup.find_all("a", {"class":"a-link-normal s-line-clamp-2 s-link-style a-text-normal"})
       # print(self.a_tags)

        device_name_span_tags = []
        for name_tag in self.a_tags:
            self.span_tag = name_tag.find("span").contents
            if self.span_tag:
                device_name_span_tags.append(self.span_tag)
        #print(device_name_span_tags)

        self.price_span_tags = self.soup.find_all("span", {"class": "a-price-whole"})
       # print(self.price_span_tags)


        device_price_span_tags = []
        for price_tag in self.price_span_tags:
            price = price_tag.contents
            if price:
                device_price_span_tags.append(price)
       # print(device_price_span_tags)


        device_name = [item[0] for item in device_name_span_tags]
        device_prices = [item[0] for item in device_price_span_tags]

        for n,p in zip(device_name,device_prices):
            print("Device name: ",n)
            print("Device price: ₹",p,"\n")

search_any = input("Enter a brand to search any mobile devices from Amazon : ")
url = f"https://www.amazon.in/s?k={search_any}&i=electronics&crid=1AZGZC2WZFI9B&sprefix=one%2Celectronics%2C264&ref=nb_sb_ss_ts-doa-p_1_3"
track = PriceTracker(url)