
from requests.auth import HTTPBasicAuth
import requests

url = "http://127.0.0.1:8000/post/"
payload = {
    "title":"2nd post by user",
    "content":" welcome to python,,posted by 2nd user ",
    "publishBy":" bcash"

}

response = requests.post(url=url, data=payload, auth=HTTPBasicAuth('user', '!@#123qwe'))
print(response.text)