import urllib.request, urllib.parse, urllib.error
from os import write

import requests
url = "https://tutedude.com/"
open_url = urllib.request.urlopen(url)

for line in open_url:
    print(line.decode().strip())

response1 = requests.get(url)
print(dir(response1))
print("Response: ",response1)
print("Status code : ",response1.status_code)
print("request headers: ",response1.request.headers)


user={
    "User_Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36"
}
response2 = requests.get(url = url,headers=user)
print("request2 headers2: ",response2.request.headers)
print("request2 headers2: ",response2.content)

# Below lines of code help to save the image content from any website
img_url = "http://127.0.0.1:8000/picture/image/WhatsApp_Image_2025-02-18_at_19.32.06_d7cd3803.jpg"
response3 = requests.get(img_url)
print("image context", response3.content)# image content
pic = response3.content
img_file = open("WhatsApp_Image_2025-02-18_at_19.32.06_d7cd3803.jpg", 'wb') # 'wb' means writing the byte
img_file.write(pic)
print("type of content is: ",type(response3.content))


#below line of code is used to get the web content in string
text_url = "http://127.0.0.1:8000/"
response4 = requests.get(text_url)
print(response4.text)
print("type of content is: ",type(response4.text))