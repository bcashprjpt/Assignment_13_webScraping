# pip install bs4 (bs4 is a Python library that stands for Beautiful Soup 4, which is a widely-used library for parsing HTML and XML documents.)
# pip install lxml (lxml is a Python library that provides a fast and feature-rich way to work with XML and HTML documents)

from bs4 import BeautifulSoup
import requests
import csv

def extractData(url):
    response = requests.get(url = url).content
    soup = BeautifulSoup(response, 'lxml')
    tag = soup.find('div',{'id' : 'mp-right'})
    print("print all the tag under this tag: ",tag) # it will print al the tags under div tag in the following website

    head_line = tag.find('h2')
    print("head line data: ", head_line) # it will print the head line under h2 tag

    all_head_line = tag.find_all('h2')
    print("all head line data: ", all_head_line) # it will print all the head line under h2 tag

    head_content = [content.text for content in all_head_line]
    print("Only topics : ",head_content) # it will print all the topic under head content

    with open('wiki_data.csv', 'w') as csv_file: # creating a file
        csv_write = csv.writer(csv_file) # enable the file to write
        csv_write.writerow(head_content) # add the content to it

extractData("https://en.wikipedia.org/wiki/Main_Page")