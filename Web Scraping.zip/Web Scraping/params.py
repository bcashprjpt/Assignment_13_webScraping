import requests
from requests.auth import HTTPBasicAuth
url = "http://127.0.0.1:8000/post/"

params = {

    "offset" : "3"
}

response = requests.get(url=url, params=params, auth=HTTPBasicAuth('user', '!@#123qwe'))
print("Your current url is : ",response.url)
print(response.text)